
<!DOCTYPE html>
<html>
	<head>



		<title>Спасибо за заказ!</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="facebook-domain-verification" content="juuzpzpbe66s5tk7nddxefgbcrz0zh" />
		<link type="text/css" rel="stylesheet" href="css/upsell.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">


		<script type="text/javascript" src="jquery.min.js"></script>
      <script type="text/javascript" src="jquery.placeholder.js"></script>
      <script type="text/javascript" src="init.js"></script>
			<script type="text/javascript" src="telegramform.js"></script>
      <script>
         var comments = JSON.parse('[]');
         var openedComments = 0;
      </script>

	  <!-- Facebook Pixel Code -->
		<script>
		!function(f,b,e,v,n,t,s)
		{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};
		if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
		n.queue=[];t=b.createElement(e);t.async=!0;
		t.src=v;s=b.getElementsByTagName(e)[0];
		s.parentNode.insertBefore(t,s)}(window, document,'script',
		'https://connect.facebook.net/en_US/fbevents.js');
		fbq('init', '735282514539037');
		fbq('track', 'PageView');
		</script>
		<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=735282514539037&ev=PageView&noscript=1"/></noscript>
<!-- End Facebook Pixel Code -->
	</head>
	<body class="man">

        <?php
////////////////////////////////////////////////////////////////////////////////Telegram отправка
        $msgs = [];
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $token = "2010710513:AAGacU8kSVJBaXcl_1k3hGbMOHVgj0TYAag";
            $chat_id = "-703930397";

            if (!empty($_POST['name']) && !empty($_POST['phone'])){
                $bot_url = "https://api.telegram.org/bot{$token}/";
                $urlForPhoto = $bot_url . "sendPhoto?chat_id=" . $chat_id;

                if(!empty($_FILES['file']['tmp_name'])) {

                    // Путь загрузки файлов
                    $path = $_SERVER['DOCUMENT_ROOT'] . '/telegramform/tmp/';

                    // Массив допустимых значений типа файла
                    $types = array('image/gif', 'image/png', 'image/jpeg');

                    // Максимальный размер файла
                    $size = 1024000;

                    // Проверяем тип файла
                     if (!in_array($_FILES['file']['type'], $types)) {
                         $msgs['err'] = 'Запрещённый тип файла.';
                        echo json_encode($msgs);
                        die();
                     }

                     // Проверяем размер файла
                     if ($_FILES['file']['size'] > $size) {
                         $msgs['err'] = 'Слишком большой размер файла.';
                        echo json_encode($msgs);
                        die('Слишком большой размер файла.');
                     }

                     // Загрузка файла и вывод сообщения
                     if (!@copy($_FILES['file']['tmp_name'], $path . $_FILES['file']['name'])) {
                         $msgs['err'] = 'Что-то пошло не так. Файл не отправлен!';
                         echo json_encode($msgs);
                     } else {
                        $filePath = $path . $_FILES['file']['name'];
                        $post_fields = array('chat_id' => $chat_id, 'photo' => new CURLFile(realpath($filePath)) );
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array( "Content-Type:multipart/form-data" ));
                        curl_setopt($ch, CURLOPT_URL, $urlForPhoto);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
                        $output = curl_exec($ch);
                        unlink($filePath);
                     }
                }

                if (isset($_POST['name'])) {
                  if (!empty($_POST['name'])){
                    $name = "Имя клиента: " . strip_tags($_POST['name']) . "%0A";
                  }
                }

                if (isset($_POST['phone'])) {
                  if (!empty($_POST['phone'])){
                    $phone = "Номер телефона: " . "%2B" . strip_tags($_POST['phone']) . "%0A";
                  }
                }

                if (isset($_POST['theme'])) {
                  if (!empty($_POST['theme'])){
                    $theme = "Тема: " .strip_tags($_POST['theme']);
                  }
                }
                // Формируем текст сообщения
                $txt = $name . $phone . $theme;

                $sendTextToTelegram = file_get_contents("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}");


            } else {
                $msgs['err'] = 'Ошибка. Вы заполнили не все обязательные поля!';
                echo json_encode($msgs);;
            }
        } else {
          header ("Location: /");
        }
        ?>



		<?php
////////////////////////////////////////////////////////////////////////////////Отправка на почту

        //проверяем, существуют ли переменные в массиве POST
	  if(!isset($_POST['name']) and !isset($_POST['phone'])){
	   ?>
	  <form id="order_form" class="order_form" action="upsell/order.php" method="post">
	    <div class="timer_block clearfix">
	      <p>До конца <span>акции осталось:</span></p>
	      <div class="timer clearfix">
	        <div class="timer_item">
	          <div class="text">часов</div>
	          <div class="count hours">00</div>
	        </div>
	        <div class="timer_item">
	          <div class="text">минут</div>
	          <div class="count minutes">00</div>
	        </div>
	        <div class="timer_item">
	          <div class="text">секунд</div>
	          <div class="count seconds">00</div>
	        </div>
	      </div>
	    </div>
	    <div class="price_block">
	      <div class="price_old">
	        <div class="text">Обычная цена:</div>
	        <div class="value">1478грн</div>
	      </div>
	      <div class="price_new">739грн</div>
	    </div>
	    <input class="input" type="text" name="name" placeholder="Введите Ваше имя" required>
	    <input class="input" id="phone" type="text" name="phone" placeholder="+38 (0__) ___ __ __" required>
	    <input type="hidden" id="product_id" name="product_id" value="269">
	    <input type="hidden" id="product_name" name="product_name" value="(Детское термо)">
	    <div class="input input-close">
	      <input class="input" type="text" name="email" placeholder="Введите Ваш email" value>
	    </div>

	    <button class="button">Сделать заказ</button>
	    <div class="products_count">Осталось <span>12</span> упаковок по акции</div>

	  </form>
	  <?php
	  } else {
	  //показываем форму
	  $name = $_POST['name'];
	  $phone = $_POST['phone'];

	  $name = htmlspecialchars($name);
	  $phone = htmlspecialchars($phone);

	  $name = urldecode($name);
	  $phone = urldecode($phone);

	  $name = trim($name);
	  $phone = trim($phone);

	  if (mail("basokbogdan@gmail.com", "Заявка с сайта", " Имя: ".$name." Номер телефона: ".$phone,"From: termalwear@gmail.com \r\n"))
	  {     echo "сообщение успешно отправлено";
	  } else {
	  echo "при отправке сообщения возникли ошибки";
	  }
	  }
	  ?>
		<div class="section block-1">
			<div class="wrap">
				<img src="image/call-girl.png">
				<div class="top-title">
					<h2>Спасибо, Ваш заказ принят!</h2>
					<div>Наш оператор свяжется с вами в ближайшие 10-15 минут</div>
					<p><b style="color:black">операторы работают без выходных с 10:00 до 22:00 </b></p>
				</div>
			</div>
		</div>
		<div class="section block-2">
			<div class="wrap">
				<h1>Пожалуйста, держите включенным Ваш телефон!</h1>
				<p></p>
			</div>
		</div>
		<center class="timer">
			<script src="megatimer/s/4cfe04346a315ffcfcc46c483227a5e6.js"></script>
		</center>



							<center>
					&larr; <a class="back" href="../">Вернуться обратно на сайт</a>
				</center>
			</div>
		</div>
		<div class="section footer">
			<div class="wrap clearfix">
				<div class="left clearfix foot-logo">
					<p>(c) Copyright 2021</p>
				</div>
				<div class="right"><p>Режим работы:
                  Пн - Вс: 08:00 - 23:00 <br>
									<?php
								  //проверяем, существуют ли переменные в массиве POST
								  if(!isset($_POST['name']) and !isset($_POST['phone'])){
								   ?>
								  <form id="order_form" class="order_form" action="upsell/order.php" method="post">
								    <div class="timer_block clearfix">
								      <p>До конца <span>акции осталось:</span></p>
								      <div class="timer clearfix">
								        <div class="timer_item">
								          <div class="text">часов</div>
								          <div class="count hours">00</div>
								        </div>
								        <div class="timer_item">
								          <div class="text">минут</div>
								          <div class="count minutes">00</div>
								        </div>
								        <div class="timer_item">
								          <div class="text">секунд</div>
								          <div class="count seconds">00</div>
								        </div>
								      </div>
								    </div>
								    <div class="price_block">
								      <div class="price_old">
								        <div class="text">Обычная цена:</div>
								        <div class="value">1478грн</div>
								      </div>
								      <div class="price_new">739грн</div>
								    </div>
								    <input class="input" type="text" name="name" placeholder="Введите Ваше имя" required>
								    <input class="input" type="tel" name="phone" placeholder="Введите Ваш телефон" required>
								    <input type="hidden" id="product_id" name="product_id" value="269">
								    <input type="hidden" id="product_name" name="product_name" value="(Детское термо)">
								    <div class="input input-close">
								      <input class="input" type="text" name="email" placeholder="Введите Ваш email" value>
								    </div>

								    <button class="button">Сделать заказ</button>
								    <div class="products_count">Осталось <span>12</span> упаковок по акции</div>

								  </form>
								  <?php
								  } else {
								  //показываем форму
								  $name = $_POST['name'];
								  $phone = $_POST['phone'];

								  $name = htmlspecialchars($name);
								  $phone = htmlspecialchars($phone);

								  $name = urldecode($name);
								  $phone = urldecode($phone);

								  $name = trim($name);
								  $phone = trim($phone);

								  if (mail("basokbogdan@gmail.com", "Заявка с сайта", " Имя: ".$name."\r\n Номер телефона: ".$phone,"From: sshostakivsky@gmail.com \r\n"))
								  {
								  } else {
								  echo "При отправке сообщения возникли ошибки";
								  }
								  }
								  ?>
			</div>
		</div>


<noscript><div><img src="https://mc.yandex.ru/watch/59226301" style="position:absolute; left:-9999px;" alt=""/></div></noscript>


	</body>
</html>
